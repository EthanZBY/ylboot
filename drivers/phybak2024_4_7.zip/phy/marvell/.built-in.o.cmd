cmd_drivers/phy/marvell/built-in.o :=  rm -f drivers/phy/marvell/built-in.o; /data/sdk/luban/u-boot/v2017.09-rk3588-skysi/toolchain/bin/aarch64-none-linux-gnu-ar rcs drivers/phy/marvell/built-in.o
